names = ['Christopher', 'Susan']
print(len(names)) # Get the number of items
names.insert(0, 'Bill') # Insert before index
print(names)
