person = {'first': 'Christopher'}
person['last'] = 'Harrison'
print(person)
print(person['first'])