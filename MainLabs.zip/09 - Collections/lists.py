names = ['Christopher', 'Susan']
scores = []
scores.append(98)
scores.append(99)
print(names)
print(scores)
