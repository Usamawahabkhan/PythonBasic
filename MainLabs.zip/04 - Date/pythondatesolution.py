from dateutil.relativedelta import relativedelta
from datetime import date, timedelta

# Define your birthday (example: 15th May 1990)
birthday = date(1990, 5, 15)

# Get today's date
today = date.today()

# 1. Find the Day of the Week for your birthday
day_of_week = birthday.strftime("%A")
print("Day of the week for birthday:", day_of_week)

# 2. Calculate exact age in years, months, and days

age = relativedelta(today, birthday)
print(f"Exact age: {age.years} years, {age.months} months, {age.days} days")

# 3. Add 100 days to a given date (using birthday as example)
future_date = birthday + timedelta(days=100)
print("Date after 100 days from birthday:", future_date)

# 4. Countdown: Days left until end of the current year
end_of_year = date(today.year, 12, 31)
days_left = (end_of_year - today).days
print("Days left until end of the year:", days_left)