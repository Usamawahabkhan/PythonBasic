def my_greet(name):
    print(f"Hello, {name}! Welcome to Python functions.")

my_greet("YourName")