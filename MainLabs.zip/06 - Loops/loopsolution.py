# Program to collect five names from the user, display them with their positions,
# and then display the names in reverse order.

# Initialize an empty list to store names
names = []

# Loop to get five names from the user
for i in range(5):
    name = input(f"Enter name {i+1}: ")  # Prompt user for a name
    names.append(name)  # Add the entered name to the list

# Print names with their positions
print("Names and their positions:")
for idx, name in enumerate(names, start=1):
    print(f"{idx}: {name}")

# Bonus: print names in reverse order
print("\nNames in reverse order:")
for idx, name in enumerate(reversed(names), start=1):
    print(f"{idx}: {name}")